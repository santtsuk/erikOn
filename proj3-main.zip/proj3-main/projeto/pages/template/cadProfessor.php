<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Cadastro de Professores</h4>
                <a href="dashboard.php?r=telaProfessor">Dados Professores</a>
            </div>
            <div class="card-body">
                <form class="row g-3" method="post" action="../_scripts/salvarProf.php">
                    <div class="col-md-12">
                        <label for="inputEmail4" class="form-label">Nome</label>
                        <input type="text" name="nome" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Nome da Mãe</label>
                        <input type="text" name="nome_mae" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Nome da Pai</label>
                        <input type="text" name="nome_pai" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">CPF</label>
                        <input type="text" id="cpf_aluno" name="cpf" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Telefone Contato</label>
                        <input type="text" id="tel_aluno" required name="telefone" class="form-control">
                    </div>
                    <div class="col-md-12">
                        <label for="inputPassword4" class="form-label">Observação</label>
                        <textarea rows="7" class="form-control" name="obs"></textarea>
                    </div>
                    <div class="col-md-12">
                        <button class="btn btn-primary" type="submit">Salvar Cadastro</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>