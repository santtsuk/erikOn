<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Cadastro de Alunos</h4>
            </div>
            <div class="card-body">
                <form class="row g-3" method="post" action="">
                    <div class="col-md-12">
                        <label for="inputEmail4" class="form-label">Nome</label>
                        <input type="text" name="nome" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Nome da Mãe</label>
                        <input type="text" name="nome_mae" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Nome da Pai</label>
                        <input type="text" name="nome_pai" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">CPF</label>
                        <input type="text" id="cpf_aluno" name="cpf" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Telefone Contato</label>
                        <input type="text" id="tel_aluno" required name="telefone" class="form-control">
                    </div>
                    <div class="col-md-12">
                        <button class="btn btn-primary" type="submit">Salvar Cadastro</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php

if (!empty($_POST)) {
    include "../_scripts/config.php";

    $nome = $_POST['nome'];
    $nome_mae = $_POST['nome_mae'];
    $nome_pai = $_POST['nome_pai'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];

    $sql = "INSERT INTO cadaluno VALUES (NULL,CURRENT_TIMESTAMP(),'$nome','$nome_mae','$nome_pai','$cpf','$telefone')";
    $query = $mysqli->query($sql);

    if ($query) {
        echo "<script>alert('Salvo com sucesso')</script>";
    } else {
        echo "<script>alert('Ouve um erro')</script>";
    }
}
?>