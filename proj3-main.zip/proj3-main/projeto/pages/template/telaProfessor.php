<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Cadastro de Alunos</h4>
            </div>
            <div class="card-body">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Nome da Mäe</th>
                            <th>Nome da Pai</th>
                            <th>telefone</th>
                            <th>CPF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>Tiger Nixon</td>
                        <td>System Architect </td>
                        <td>Edinburgh</td>
                        <td>61</td>
                        <td>2011-04-25</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Nome</th>
                            <th>Nome da Mäe</th>
                            <th>Nome da Pai</th>
                            <th>telefone</th>
                            <th>CPF</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>