<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Cadastro de Professores</h4>
            </div>
            <div class="card-body">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th style="text-align: center;">Nome</th>
                            <th style="text-align: center;">Nome da Mäe</th>
                            <th style="text-align: center;">Nome da Pai</th>
                            <th style="text-align: center;">telefone</th>
                            <th style="text-align: center;">CPF</th>
                            <th style="text-align: center;">Editar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = dadosProfessor();
                        while ($dados = $query->fetch_array()) {

                        ?>
                            <tr>
                                <td style="text-align: center;">
                                    <?php echo $dados['nome_aluno']; ?></td>
                                <td style="text-align: center;"> <?php echo $dados['nome_mae']; ?></td>
                                <td style="text-align: center;"> <?php echo $dados['nome_pai']; ?></td>
                                <td style="text-align: center;"> <?php echo $dados['telefone']; ?></td>
                                <td style="text-align: center;"> <?php echo $dados['cpf']; ?></td>
                                <td style="text-align: center;">
                                    <i class="fa-solid fa-pen-to-square btn btn-primary"></i>
                                    <a href="../_scripts/deleteProfessor.php?id=<?php echo $dados['id']; ?>"><i class="fas fa-trash btn btn-danger">
                                        </i>
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th style="text-align: center;">Nome</th>
                            <th style="text-align: center;">Nome da Mäe</th>
                            <th style="text-align: center;">Nome da Pai</th>
                            <th style="text-align: center;">telefone</th>
                            <th style="text-align: center;">Editar</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>