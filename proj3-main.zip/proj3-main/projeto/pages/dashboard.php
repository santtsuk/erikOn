<?php include "head.php"; ?>

<body class="">
    <div class="wrapper ">
        <?php include "menu.php" ?>
        <div class="main-panel">
            <!-- Navbar -->
            <?php include "header.php"; ?>
            <!-- End Navbar -->
            <div class="content">
                <?php include "cards.php"; ?>
                <?php
                switch ($_GET['r']) {
                    case 'cadAluno':
                        include "template/cadAluno.php";
                        break;

                    case "cadProfessor":
                        include "template/cadProfessor.php";
                        break;
                    case "telaProfessor":
                        include "template/telaProfessor.php";
                        break;
                }
                ?>
            </div>
            <?php include "footer.php"; ?>
        </div>
    </div>
    <?php include "js.php"; ?>
</body>

</html>