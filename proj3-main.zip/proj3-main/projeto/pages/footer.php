<footer class="footer footer-black  footer-white ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script>, Feito com <i class="fa fa-heart heart"></i> by Eu mesmo
                            </span>
                        </div>
                    </div>
                </div>
            </footer>