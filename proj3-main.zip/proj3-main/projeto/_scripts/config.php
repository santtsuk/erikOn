<?php
$servidor = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'escola_on';

$mysqli = new mysqli($servidor, $usuario, $senha,$banco)
?>