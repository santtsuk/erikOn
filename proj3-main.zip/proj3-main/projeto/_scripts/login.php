<?php

$login = $_POST['login'];
$senha = md5($_POST['senha']);

if($total_login==1){//verificação do login

    if($total_senha==1){//verifica login e senha

        echo "<script>alert('Logado')</script>";//logado com sucesso
    }else{
        echo "<script>alert('erro')</script>";//erro na senha
    }

}else{
    echo "<script>alert('erro')</script>";//erro no login
}



?>