<html>

<body>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php
    include("config.php");

    if (!empty($_GET)) {
        include "config.php";

        $id = $_GET['id'];

        $sql = "DELETE FROM cadprofessor WHERE id = $id";
        $query = $mysqli->query($sql);

        if ($query) { ?>
            <script language="JavaScript">
                Swal.fire({
                    title: "Sucesso!",
                    text: "Cadastrado com successo!",
                    icon: "success"
                }).then(okay => {
                    if (okay) {
                        window.location.href = "../pages/dashboard.php?r=cadProfessor";
                    }
                })
            </script>

        <?php } else { ?>

            <script language="JavaScript">
                swal.fire({
                    icon: "warning",
                    text: "Erro!"
                })
            </script>

    <?php
        }
    }
    ?>
</body>

</html>