<?php

function qtdeALunos()
{
    include "config.php";

    $rs = "SELECT * FROM cadAluno";
    $query = $mysqli->query($rs);
    $total = $query->num_rows;

    return $total;
}

function qtdeProfessores()
{
    include "config.php";

    $rs = "SELECT * FROM cadprofessor";
    $query = $mysqli->query($rs);
    $total = $query->num_rows;

    return $total;
}
