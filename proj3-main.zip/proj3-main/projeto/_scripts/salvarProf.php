<html>

<body>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php
    include("config.php");

    if (!empty($_POST)) {
        include "../_scripts/config.php";

        $nome = $_POST['nome'];
        $nome_mae = $_POST['nome_mae'];
        $nome_pai = $_POST['nome_pai'];
        $cpf = $_POST['cpf'];
        $telefone = $_POST['telefone'];
        $obs = $_POST['obs'];

        $sql = "INSERT INTO cadaluno VALUES (NULL,CURRENT_TIMESTAMP(),'$nome','$nome_mae','$nome_pai','$cpf','$telefone','$obs')";
        $query = $mysqli->query($sql);

        if ($query) { ?>
            <script language="JavaScript">
                Swal.fire({
                    title: "Sucesso!",
                    text: "Cadastrado com successo!",
                    icon: "success"
                }).then(okay => {
                    if (okay) {
                        window.location.href = "../pages/dashboard.php?r=cadProfessor";
                    }
                })
            </script>

        <?php } else { ?>

            <script language="JavaScript">
                swal.fire({
                    icon: "warning",
                    text: "Erro!"
                })
            </script>

    <?php
        }
    }
    ?>
</body>